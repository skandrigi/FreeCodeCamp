# Random Quote Machine | Sandeep Kandrigi

A Pen created on CodePen.io. Original URL: [https://codepen.io/skandrigi/pen/YzJVJaZ](https://codepen.io/skandrigi/pen/YzJVJaZ).

